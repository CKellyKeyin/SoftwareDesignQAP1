import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import java.util.List;

public class StudentsTest {
    private Students studentsUnderTest = new Students();

@Test

public void testListEmpty(){
    Assertions.assertNull(studentsUnderTest);
}



    @Test

    public void testSize()
    {
        studentsUnderTest.addStudent("Han");
        studentsUnderTest.addStudent("Luke");
        studentsUnderTest.addStudent("Ben");
        studentsUnderTest.addStudent("Leia");
        Assertions.assertEquals(4, studentsUnderTest.sizeOfStudent());


    }

@Test
    public void testListNotEmpty()
{
    Assertions.assertNotNull(studentsUnderTest);
}

}
