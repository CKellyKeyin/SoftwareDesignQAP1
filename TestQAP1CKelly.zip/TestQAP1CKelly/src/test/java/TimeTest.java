import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


public class TimeTest {


    @Test
    public int void testSetHour(){
        Time timeUnderTest = new Time();
        int resultOne = timeUnderTest.setHour(21);


        Assertions.assertEquals(21, resultOne);

    }

    @Test
    public void testCancel() {
        Time timeUnderTest = new Time();

        Assertions.assertTrue(timeUnderTest.isActive());

        timeUnderTest.cancel();

        Assertions.assertFalse(timeUnderTest.isActive());

    }

}
