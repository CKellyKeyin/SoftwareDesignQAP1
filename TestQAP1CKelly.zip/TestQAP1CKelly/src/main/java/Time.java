public class Time{
    private int hour, minute, second;
    private boolean active;


    public Time() {
        this.active = true;
    }
    private static void hourConstraint(int hour) {
        if (hour < 0 || hour > 23) {
            throw new IllegalArgumentException("Hour must be between 0 and 23.");
        }
    }

    private static void minuteConstraint(int minute) {
        if (minute < 0 || minute > 59) {
            throw new IllegalArgumentException("Minute must be between 0 and 59.");
        }
    }

    private static void secondConstraint(int second) {
        if (second < 0 || second > 59) {
            throw new IllegalArgumentException("Second must be between 0 and 59.");
        }
    }


    public Time(int hour, int minute, int second){
        hourConstraint(hour);
        minuteConstraint(minute);
        secondConstraint(second);
        this.hour = hour;
        this.minute = minute;
        this.second = second;
    }

    public int getSecond(){
        return second;
    }

    public void setSecond(int second){
        secondConstraint(second);
        this.second = second;
    }

    public int getMinute(){
        return minute;

    }

    public void setMinute(int minute){
        minuteConstraint(minute);
        this.minute = minute;
    }

    public int getHour(){
        return hour;
    }

    public void setHour(int hour){
        hourConstraint(hour);
        this.hour = hour;
    }

    public void cancel() {
        this.active = false;
    }

    public void setTime (int hour, int minute, int second){
        hourConstraint(hour);
        minuteConstraint(minute);
        secondConstraint(second);
        this.hour = hour;
        this.minute = minute;
        this.second = second;
    }

    public String timeToString(){
        return String.format("%02d:%02d:%02d", hour, minute, second);
    }

    public Time nextSecond() {
        second++;
        if (second == 60) {
            second = 0;
            minute++;
            if (minute == 60) {
                minute = 0;
                hour++;
                if (hour == 24) {
                    hour = 0;
                }
            }
        }
        return this;
    }



    public Time previousSecond() {
        second--;
        if (second == -1) {
            second = 59;
            minute--;
            if (minute == -1) {
                minute = 59;
                hour--;
                if (hour == -1) {
                    hour = 23;
                }
            }
        }
        return this;
    }

}



