import java.util.ArrayList;
import java.util.List;

public class Students {
    private List<String> students = new ArrayList<String>();
    public void remove(String name) {
        students.remove(name);
    }

    public void addStudent(String name) {
        students.add(name);
    }



    public void removeAllStudents(){
        students.clear();
    }

    public int sizeOfStudent() {
        return students.size();
    }

    public Students studentListEmpty(){
        if (students.size() > 0) {


        }
        return null;
    }
}

